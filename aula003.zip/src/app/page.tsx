import Card, { Auxiliar } from "./components/Card/page";
import Header from "./components/Header/Header";
import Meucomponente from "./components/Meucomponente/page";

export default function Home(){
  return(
    <>
    
    <h1>Hello world!</h1>

    <Card></Card>
    <Card />

    <Meucomponente />
    <Auxiliar></Auxiliar>
    </>
  )
}