export default function Header(){
    return(
        <>
            <header style={{width:'100%', backgroundColor:"blue", height:"100px"}}>Cabeçalho</header>
        </>
    )
}