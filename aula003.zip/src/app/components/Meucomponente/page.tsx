
// Comentario
/* Comentario de mais de uma linha */
const Meucomponente = () => {
    return(
        <>
        {/* Criando Arrow function */ }
            <h1>Meu componente, criado com Arrow function</h1>
        </>

    )

}
export default Meucomponente;